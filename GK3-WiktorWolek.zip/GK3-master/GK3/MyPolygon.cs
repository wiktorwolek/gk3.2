﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace PolygonEditor
{
    public class MyPolygon : MyShape
    {
        double epsilon = 1e-8;
        public bool isFinished = false;
        public Guid id = Guid.NewGuid();
        public List<MyPoint> vertexes = new List<MyPoint>();
        List<(int ind1, int ind2, Color c)> colors = new List<(int ind1, int ind2, Color c)>();
        public bool drawBresenham = false;
        // ------------------ FUNCTIONS FOR VERTEX MANIPULATION --------------------
        public MyPoint GetLastVertex()
        {
            if (vertexes.Count == 0)
                return null;
            return vertexes[vertexes.Count - 1];
        }
        public List<Point> GetPoints()
        {
            List<Point> points = new List<Point>();
            foreach(var e in vertexes) points.Add(new Point((int)e.x,(int) e.y));
            return points;
        }
        
        public void AddVertex(MyPoint p)
        {
            vertexes.Add(p);
        }
      
      
        public void Finish()
        {
            isFinished = true;
        }
     
   
        override public void DrawVertexes(Graphics g, Pen pen)
        {
            foreach (var v in vertexes)
                v.DrawShape(g, pen);
        }
        override public void DrawShape(Graphics g, Pen pen)
        {
            if (vertexes.Count == 0) return;
            DrawVertexes(g, pen);
            MyPoint x1 = vertexes[vertexes.Count - 1], x2 = vertexes[0];
          
            if (isFinished)
            {
                if (x1.IsSelected() && x2.IsSelected()) pen.Color = Color.Red;
                else g.DrawLine(pen, (int)x1.x, (int)x1.y, (int)x2.x, (int)x2.y);
                pen.Color = Color.Black;
            }
            for (int i = 0; i < vertexes.Count - 1; i++)
            {
                x1 = vertexes[i];
                x2 = vertexes[i + 1];
                if (x1.IsSelected() && x2.IsSelected()) pen.Color = Color.Red;
                for (int j = 0; j < colors.Count; j++)
                {
                    if ((colors[j].ind1 == i && colors[j].ind2 == i+1) ||
                        colors[j].ind1 == i+1 && colors[j].ind2 == i)
                    {
                        pen.Color = colors[j].c;
                    }
                }
                g.DrawLine(pen, (int)x1.x, (int)x1.y, (int)x2.x, (int)x2.y);
                pen.Color = Color.Black;
                pen.Width = 1;
               
            }
        }
    }
}
