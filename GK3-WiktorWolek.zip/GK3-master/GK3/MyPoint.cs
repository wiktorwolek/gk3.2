﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace PolygonEditor
{
    public class MyPoint
    {
        private bool selected = false;
        public double x { get; set; }
        public double y { get; set; }
        public MyPoint(double _x, double _y)
        {
            x = _x;
            y = _y;
        }

        public MyPoint()
        {
            x = 0;
            y = 0;
        }

        public void SelectPoint()
        {
            selected = true;
        }

        public void UnselectPoint()
        {
            selected = false;
        }

        public bool IsSelected()
        {
            return selected;
        }

        public void DrawShape(Graphics g, Pen pen)
        {
            if (selected)
                pen.Color = Color.Red;

            g.DrawEllipse(pen, (int)x - 6, (int)y - 6, 12, 12);
            g.DrawRectangle(pen, (int)x, (int)y, 1, 1);
            pen.Color = Color.Black;
        }
        public int DistToPoint(MyPoint p)
        {
            return (int)Math.Sqrt((x - p.x) * (x - p.x) + (y - p.y) * (y - p.y));
        }

        public bool CheckIfClicked(MyPoint p)
        {
            if (p.x <= this.x + 6 && p.x >= this.x - 6 && p.y <= this.y + 6 && p.y >= this.y - 6)
                return true;
            return false;
        }
        static public double Distance(MyPoint a,MyPoint b)
        {
            return Math.Sqrt((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y));
        }
    }
}
