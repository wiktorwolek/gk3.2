﻿namespace GK3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MainPictureBox = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Gaussian = new System.Windows.Forms.RadioButton();
            this.Sharpen = new System.Windows.Forms.RadioButton();
            this.Blur = new System.Windows.Forms.RadioButton();
            this.Identity = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.CustomFilterInput9 = new System.Windows.Forms.NumericUpDown();
            this.CustomFilterInput8 = new System.Windows.Forms.NumericUpDown();
            this.CustomFilterInput7 = new System.Windows.Forms.NumericUpDown();
            this.CustomFilterInput6 = new System.Windows.Forms.NumericUpDown();
            this.CustomFilterInput5 = new System.Windows.Forms.NumericUpDown();
            this.CustomFilterInput4 = new System.Windows.Forms.NumericUpDown();
            this.CustomFilterInput3 = new System.Windows.Forms.NumericUpDown();
            this.CustomFilterInput2 = new System.Windows.Forms.NumericUpDown();
            this.CustomFilterInput1 = new System.Windows.Forms.NumericUpDown();
            this.Custom = new System.Windows.Forms.RadioButton();
            this.Original = new System.Windows.Forms.RadioButton();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.load = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.BrushRadious = new System.Windows.Forms.NumericUpDown();
            this.Polygon = new System.Windows.Forms.RadioButton();
            this.Brush = new System.Windows.Forms.RadioButton();
            this.Whole = new System.Windows.Forms.RadioButton();
            this.cartesianChart1 = new LiveCharts.WinForms.CartesianChart();
            ((System.ComponentModel.ISupportInitialize)(this.MainPictureBox)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CustomFilterInput9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CustomFilterInput8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CustomFilterInput7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CustomFilterInput6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CustomFilterInput5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CustomFilterInput4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CustomFilterInput3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CustomFilterInput2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CustomFilterInput1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BrushRadious)).BeginInit();
            this.SuspendLayout();
            // 
            // MainPictureBox
            // 
            this.MainPictureBox.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.MainPictureBox.Location = new System.Drawing.Point(9, 8);
            this.MainPictureBox.Name = "MainPictureBox";
            this.MainPictureBox.Size = new System.Drawing.Size(800, 450);
            this.MainPictureBox.TabIndex = 0;
            this.MainPictureBox.TabStop = false;
            this.MainPictureBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.MainPictureBox_MouseClick);
            this.MainPictureBox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.MainPictureBox_MouseMove);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Gaussian);
            this.groupBox1.Controls.Add(this.Sharpen);
            this.groupBox1.Controls.Add(this.Blur);
            this.groupBox1.Controls.Add(this.Identity);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.Custom);
            this.groupBox1.Controls.Add(this.Original);
            this.groupBox1.Location = new System.Drawing.Point(10, 47);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(390, 298);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Filter options";
            // 
            // Gaussian
            // 
            this.Gaussian.AutoSize = true;
            this.Gaussian.Location = new System.Drawing.Point(6, 119);
            this.Gaussian.Name = "Gaussian";
            this.Gaussian.Size = new System.Drawing.Size(99, 19);
            this.Gaussian.TabIndex = 7;
            this.Gaussian.TabStop = true;
            this.Gaussian.Text = "Gaussian filter";
            this.Gaussian.UseVisualStyleBackColor = true;
            this.Gaussian.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // Sharpen
            // 
            this.Sharpen.AutoSize = true;
            this.Sharpen.Location = new System.Drawing.Point(6, 94);
            this.Sharpen.Name = "Sharpen";
            this.Sharpen.Size = new System.Drawing.Size(95, 19);
            this.Sharpen.TabIndex = 6;
            this.Sharpen.TabStop = true;
            this.Sharpen.Text = "Sharpen filter";
            this.Sharpen.UseVisualStyleBackColor = true;
            this.Sharpen.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // Blur
            // 
            this.Blur.AutoSize = true;
            this.Blur.Location = new System.Drawing.Point(6, 69);
            this.Blur.Name = "Blur";
            this.Blur.Size = new System.Drawing.Size(73, 19);
            this.Blur.TabIndex = 5;
            this.Blur.TabStop = true;
            this.Blur.Text = "Blur filter";
            this.Blur.UseVisualStyleBackColor = true;
            this.Blur.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // Identity
            // 
            this.Identity.AutoSize = true;
            this.Identity.Location = new System.Drawing.Point(6, 44);
            this.Identity.Name = "Identity";
            this.Identity.Size = new System.Drawing.Size(92, 19);
            this.Identity.TabIndex = 4;
            this.Identity.TabStop = true;
            this.Identity.Text = "Identity filter";
            this.Identity.UseVisualStyleBackColor = true;
            this.Identity.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.CustomFilterInput9);
            this.groupBox2.Controls.Add(this.CustomFilterInput8);
            this.groupBox2.Controls.Add(this.CustomFilterInput7);
            this.groupBox2.Controls.Add(this.CustomFilterInput6);
            this.groupBox2.Controls.Add(this.CustomFilterInput5);
            this.groupBox2.Controls.Add(this.CustomFilterInput4);
            this.groupBox2.Controls.Add(this.CustomFilterInput3);
            this.groupBox2.Controls.Add(this.CustomFilterInput2);
            this.groupBox2.Controls.Add(this.CustomFilterInput1);
            this.groupBox2.Location = new System.Drawing.Point(3, 169);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(384, 119);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Custom filter settings";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // CustomFilterInput9
            // 
            this.CustomFilterInput9.Location = new System.Drawing.Point(258, 80);
            this.CustomFilterInput9.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.CustomFilterInput9.Name = "CustomFilterInput9";
            this.CustomFilterInput9.Size = new System.Drawing.Size(120, 23);
            this.CustomFilterInput9.TabIndex = 10;
            this.CustomFilterInput9.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.CustomFilterInput9.ValueChanged += new System.EventHandler(this.CustomFilterInput9_ValueChanged);
            // 
            // CustomFilterInput8
            // 
            this.CustomFilterInput8.Location = new System.Drawing.Point(132, 80);
            this.CustomFilterInput8.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.CustomFilterInput8.Name = "CustomFilterInput8";
            this.CustomFilterInput8.Size = new System.Drawing.Size(120, 23);
            this.CustomFilterInput8.TabIndex = 9;
            this.CustomFilterInput8.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.CustomFilterInput8.ValueChanged += new System.EventHandler(this.CustomFilterInput8_ValueChanged);
            // 
            // CustomFilterInput7
            // 
            this.CustomFilterInput7.Location = new System.Drawing.Point(6, 80);
            this.CustomFilterInput7.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.CustomFilterInput7.Name = "CustomFilterInput7";
            this.CustomFilterInput7.Size = new System.Drawing.Size(120, 23);
            this.CustomFilterInput7.TabIndex = 8;
            this.CustomFilterInput7.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.CustomFilterInput7.ValueChanged += new System.EventHandler(this.CustomFilterInput7_ValueChanged);
            // 
            // CustomFilterInput6
            // 
            this.CustomFilterInput6.Location = new System.Drawing.Point(258, 51);
            this.CustomFilterInput6.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.CustomFilterInput6.Name = "CustomFilterInput6";
            this.CustomFilterInput6.Size = new System.Drawing.Size(120, 23);
            this.CustomFilterInput6.TabIndex = 7;
            this.CustomFilterInput6.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.CustomFilterInput6.ValueChanged += new System.EventHandler(this.CustomFilterInput6_ValueChanged);
            // 
            // CustomFilterInput5
            // 
            this.CustomFilterInput5.Location = new System.Drawing.Point(132, 51);
            this.CustomFilterInput5.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.CustomFilterInput5.Name = "CustomFilterInput5";
            this.CustomFilterInput5.Size = new System.Drawing.Size(120, 23);
            this.CustomFilterInput5.TabIndex = 6;
            this.CustomFilterInput5.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.CustomFilterInput5.ValueChanged += new System.EventHandler(this.CustomFilterInput5_ValueChanged);
            // 
            // CustomFilterInput4
            // 
            this.CustomFilterInput4.Location = new System.Drawing.Point(6, 51);
            this.CustomFilterInput4.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.CustomFilterInput4.Name = "CustomFilterInput4";
            this.CustomFilterInput4.Size = new System.Drawing.Size(120, 23);
            this.CustomFilterInput4.TabIndex = 5;
            this.CustomFilterInput4.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.CustomFilterInput4.ValueChanged += new System.EventHandler(this.CustomFilterInput4_ValueChanged);
            // 
            // CustomFilterInput3
            // 
            this.CustomFilterInput3.Location = new System.Drawing.Point(258, 22);
            this.CustomFilterInput3.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.CustomFilterInput3.Name = "CustomFilterInput3";
            this.CustomFilterInput3.Size = new System.Drawing.Size(120, 23);
            this.CustomFilterInput3.TabIndex = 4;
            this.CustomFilterInput3.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.CustomFilterInput3.ValueChanged += new System.EventHandler(this.CustomFilterInput3_ValueChanged);
            // 
            // CustomFilterInput2
            // 
            this.CustomFilterInput2.Location = new System.Drawing.Point(132, 22);
            this.CustomFilterInput2.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.CustomFilterInput2.Name = "CustomFilterInput2";
            this.CustomFilterInput2.Size = new System.Drawing.Size(120, 23);
            this.CustomFilterInput2.TabIndex = 3;
            this.CustomFilterInput2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.CustomFilterInput2.ValueChanged += new System.EventHandler(this.CustomFilterInput2_ValueChanged);
            // 
            // CustomFilterInput1
            // 
            this.CustomFilterInput1.Location = new System.Drawing.Point(6, 22);
            this.CustomFilterInput1.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.CustomFilterInput1.Name = "CustomFilterInput1";
            this.CustomFilterInput1.Size = new System.Drawing.Size(120, 23);
            this.CustomFilterInput1.TabIndex = 2;
            this.CustomFilterInput1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.CustomFilterInput1.ValueChanged += new System.EventHandler(this.CustomFilterInput1_ValueChanged);
            // 
            // Custom
            // 
            this.Custom.AutoSize = true;
            this.Custom.Location = new System.Drawing.Point(6, 144);
            this.Custom.Name = "Custom";
            this.Custom.Size = new System.Drawing.Size(94, 19);
            this.Custom.TabIndex = 1;
            this.Custom.TabStop = true;
            this.Custom.Text = "Custom filter";
            this.Custom.UseVisualStyleBackColor = true;
            this.Custom.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // Original
            // 
            this.Original.AutoSize = true;
            this.Original.Checked = true;
            this.Original.Location = new System.Drawing.Point(6, 19);
            this.Original.Name = "Original";
            this.Original.Size = new System.Drawing.Size(103, 19);
            this.Original.TabIndex = 0;
            this.Original.TabStop = true;
            this.Original.Text = "Original image";
            this.Original.UseVisualStyleBackColor = true;
            this.Original.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // trackBar1
            // 
            this.trackBar1.Location = new System.Drawing.Point(269, 18);
            this.trackBar1.Maximum = 100;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(129, 45);
            this.trackBar1.TabIndex = 4;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.trackBar1);
            this.groupBox3.Controls.Add(this.button2);
            this.groupBox3.Controls.Add(this.load);
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Controls.Add(this.groupBox1);
            this.groupBox3.Location = new System.Drawing.Point(815, -1);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(409, 459);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(146, 18);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(119, 23);
            this.button2.TabIndex = 5;
            this.button2.Text = "Genrate";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // load
            // 
            this.load.Location = new System.Drawing.Point(13, 18);
            this.load.Name = "load";
            this.load.Size = new System.Drawing.Size(126, 23);
            this.load.TabIndex = 4;
            this.load.Text = "Load image";
            this.load.UseVisualStyleBackColor = true;
            this.load.Click += new System.EventHandler(this.load_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button1);
            this.groupBox4.Controls.Add(this.BrushRadious);
            this.groupBox4.Controls.Add(this.Polygon);
            this.groupBox4.Controls.Add(this.Brush);
            this.groupBox4.Controls.Add(this.Whole);
            this.groupBox4.Location = new System.Drawing.Point(11, 338);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(387, 115);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Area options";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(135, 72);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(120, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "New Polygon";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // BrushRadious
            // 
            this.BrushRadious.Location = new System.Drawing.Point(135, 47);
            this.BrushRadious.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.BrushRadious.Name = "BrushRadious";
            this.BrushRadious.Size = new System.Drawing.Size(120, 23);
            this.BrushRadious.TabIndex = 11;
            this.BrushRadious.Value = new decimal(new int[] {
            25,
            0,
            0,
            0});
            this.BrushRadious.ValueChanged += new System.EventHandler(this.BrushRadious_ValueChanged);
            // 
            // Polygon
            // 
            this.Polygon.AutoSize = true;
            this.Polygon.Location = new System.Drawing.Point(6, 72);
            this.Polygon.Name = "Polygon";
            this.Polygon.Size = new System.Drawing.Size(69, 19);
            this.Polygon.TabIndex = 2;
            this.Polygon.Text = "Polygon";
            this.Polygon.UseVisualStyleBackColor = true;
            this.Polygon.CheckedChanged += new System.EventHandler(this.Whole_CheckedChanged);
            // 
            // Brush
            // 
            this.Brush.AutoSize = true;
            this.Brush.Location = new System.Drawing.Point(6, 47);
            this.Brush.Name = "Brush";
            this.Brush.Size = new System.Drawing.Size(85, 19);
            this.Brush.TabIndex = 1;
            this.Brush.Text = "Paint brush";
            this.Brush.UseVisualStyleBackColor = true;
            this.Brush.CheckedChanged += new System.EventHandler(this.Whole_CheckedChanged);
            // 
            // Whole
            // 
            this.Whole.AutoSize = true;
            this.Whole.Checked = true;
            this.Whole.Location = new System.Drawing.Point(6, 22);
            this.Whole.Name = "Whole";
            this.Whole.Size = new System.Drawing.Size(95, 19);
            this.Whole.TabIndex = 0;
            this.Whole.TabStop = true;
            this.Whole.Text = "Whole image";
            this.Whole.UseVisualStyleBackColor = true;
            this.Whole.CheckedChanged += new System.EventHandler(this.Whole_CheckedChanged);
            // 
            // cartesianChart1
            // 
            this.cartesianChart1.Location = new System.Drawing.Point(12, 464);
            this.cartesianChart1.Name = "cartesianChart1";
            this.cartesianChart1.Size = new System.Drawing.Size(1212, 196);
            this.cartesianChart1.TabIndex = 3;
            this.cartesianChart1.Text = "histogram";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1227, 672);
            this.Controls.Add(this.cartesianChart1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.MainPictureBox);
            this.Name = "Form1";
            this.Text = "GK3";
            ((System.ComponentModel.ISupportInitialize)(this.MainPictureBox)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.CustomFilterInput9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CustomFilterInput8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CustomFilterInput7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CustomFilterInput6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CustomFilterInput5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CustomFilterInput4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CustomFilterInput3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CustomFilterInput2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CustomFilterInput1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BrushRadious)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private PictureBox MainPictureBox;
        private GroupBox groupBox1;
        private RadioButton Original;
        private GroupBox groupBox2;
        private RadioButton Custom;
        private NumericUpDown CustomFilterInput1;
        private NumericUpDown CustomFilterInput9;
        private NumericUpDown CustomFilterInput8;
        private NumericUpDown CustomFilterInput7;
        private NumericUpDown CustomFilterInput6;
        private NumericUpDown CustomFilterInput5;
        private NumericUpDown CustomFilterInput4;
        private NumericUpDown CustomFilterInput3;
        private NumericUpDown CustomFilterInput2;
        private RadioButton Sharpen;
        private RadioButton Blur;
        private RadioButton Identity;
        private RadioButton Gaussian;
        private GroupBox groupBox3;
        private GroupBox groupBox4;
        private RadioButton Polygon;
        private RadioButton Brush;
        private RadioButton Whole;
        private NumericUpDown BrushRadious;
        private Button button1;
        private LiveCharts.WinForms.CartesianChart cartesianChart1;
        private Button load;
        private Button button2;
        private TrackBar trackBar1;
    }
}