﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GK3
{
    public class Filter
    {
        public int[,] matrix = new int[3,3];
        public int K;
        public Filter(int[,] matrix)
        {
            this.matrix = matrix;
            K = 0;
            foreach(var e in matrix)
            {
                K += e;
            }
        }
        public void changeFilter(int i,int j , int val)
        {
            matrix[i, j] = val;
            K = 0;
            foreach (var e in matrix)
            {
                K += e;
            }
        }
        public Color calculateColor(Bitmap bmp, int x, int y)
        {
            int R = 0;
            int G = 0;
            int B = 0;
            if (x==10)
            {
                int a = 0;
                Color c = bmp.GetPixel(x, y);
            }
            for (int i=0; i < matrix.GetLength(0);i++)
                for(int j=0;j< matrix.GetLength(1); j++)
                {
                    
                    int a = x + i - matrix.GetLength(0)/2;
                    int b =   y + j - matrix.GetLength(1)/2;
                    if (a < 0 || a >= bmp.Width || b < 0 || b >= bmp.Height)
                    {
                        return bmp.GetPixel(x, y);
                    }
                    R += bmp.GetPixel(a, b).R * matrix[i,j];
                    G += bmp.GetPixel(a, b).G * matrix[i,j];
                    B += bmp.GetPixel(a, b).B * matrix[i,j];
                }
            if (K == 0)
                K = 1;
            R /= K;
            G /= K;
            B /= K;
            Color newp = Color.FromArgb(255, cutTo255(R), cutTo255(G), cutTo255(B));
            return newp;
        }
        public int cutTo255(int a)
        {
            if (a > 255)
                return 255;
            else if (a < 0)
                return 0;
            else
                return a;
        }
    }
}
