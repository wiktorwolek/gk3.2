using LiveCharts;
using LiveCharts.Wpf;
using PolygonEditor;

namespace GK3
{
    public partial class Form1 : Form
    {
        Image image;
        Filter customFilter;
        Filter identityFilter = new Filter(new int[,] { { 0, 0, 0 }, { 0, 1, 0 }, { 0, 0, 0 } });
        Filter blurFilter = new Filter(new int[,] { { 1,1, 1 }, { 1, 1, 1 }, { 1, 1, 1 } });
        Filter sharpenFilter = new Filter(new int[,] { { 0, -1, 0 }, { -1, 5, -1 }, { 0, -1, 0 } });
        Filter gaussianFilter = new Filter(new int[,] { { 1, 2, 1 }, { 2, 4, 2 }, { 1, 2, 1 } });
        FilterType filterType = FilterType.Original;
        DrawType drawType = DrawType.whole;
        Point brushPosition = new Point(0, 0);
        MyPolygon currentPolygon;
        Bitmap filteredImage;
        Graphics g;
        Pen pen;
        int radius = 25;
        private enum FilterType{
            Original,
            Custom,
            identity,
            blur,
            sharpen,
            gaussian
        };
        private enum DrawType
        {
            whole,
            brush,
            polygon
        }
        public Form1()
        {
           
            currentPolygon = new MyPolygon();
            image = Image.FromFile(Path.GetFullPath("./Images/Mount-Fuji.jpg"));
            customFilter = new Filter(new int[,] { { 1, 1, 1 }, { 1, 10, 1 }, { 1, 1, 1 } });
            
            InitializeComponent();
            Bitmap objBitmap = new Bitmap(image, new Size(MainPictureBox.Width, MainPictureBox.Height));
            MainPictureBox.Image = objBitmap;
            g = Graphics.FromImage(MainPictureBox.Image);
            pen = new Pen(Color.Black, 1);
            GenerateHistogram();
        }
        private void GenerateHistogram()
        {
            cartesianChart1.AxisY = new AxesCollection();
            cartesianChart1.AxisX = new AxesCollection();
            cartesianChart1.AxisY.Add(new Axis { MinValue = 0 });
            cartesianChart1.AxisX.Add(new Axis { Separator = new Separator() { Step=10} });
            Bitmap objBitmap = new Bitmap(image, new Size(MainPictureBox.Width, MainPictureBox.Height));
            SeriesCollection seriesCollection = new SeriesCollection();
            double[] valuesR = new double[256];
            double[] valuesG = new double[256];
            double[] valuesB = new double[256];
            List<double> values = new List<double>();
            for (int i = 0; i < objBitmap.Width; i++)
            {
                for (int j = 0; j < objBitmap.Height; j++)
                {
                    valuesR[objBitmap.GetPixel(i, j).R] += 1;
                    valuesG[objBitmap.GetPixel(i, j).G] += 1;
                    valuesB[objBitmap.GetPixel(i, j).B] += 1;
                }
            }
            var redBrush = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Colors.Red);
            var greenBrush = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Colors.Green);
            var blueBrush = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Colors.Blue);
            LineSeries RSeries = new LineSeries() { Title="Red",Values = new ChartValues<double>(valuesR)};
            LineSeries GSeries = new LineSeries() { Title = "Green", Values = new ChartValues<double>(valuesG) };
            LineSeries BSeries = new LineSeries() { Title = "Blue", Values = new ChartValues<double>(valuesB) };
            RSeries.Fill = redBrush;
            RSeries.PointGeometry = null;
            RSeries.Stroke = redBrush;
            RSeries.Fill.Opacity=0.1;
            seriesCollection.Add(RSeries);
            GSeries.Fill = greenBrush;
            GSeries.PointGeometry = null;
            GSeries.Stroke = greenBrush;
            GSeries.Fill.Opacity = 0.1;
            seriesCollection.Add(GSeries);
            BSeries.Fill = blueBrush;
            BSeries.PointGeometry = null;
            BSeries.Stroke = blueBrush;
            BSeries.Fill.Opacity = 0.1;
            seriesCollection.Add(BSeries);
            cartesianChart1.Series = seriesCollection;
            cartesianChart1.DataTooltip = null;
        }
        private Bitmap DrawWithFilter(Filter f)
        {
            Bitmap newImage = new Bitmap(image, new Size(MainPictureBox.Width, MainPictureBox.Height));
            g = Graphics.FromImage(newImage);
            pen =new Pen(new TextureBrush(filteredImage));
            TextureBrush texture = new TextureBrush(filteredImage);
            switch (drawType)
            {
                case DrawType.whole:
                    newImage = filteredImage;
                    break;
                case DrawType.brush:
                    g.FillEllipse(texture, brushPosition.X - radius, brushPosition.Y - radius, 2 * radius, 2 * radius);
                    break;
                case DrawType.polygon:
                    if(currentPolygon.isFinished)
                    g.FillPolygon(texture, currentPolygon.GetPoints().ToArray());
                    break;
            }
            
            return newImage;
        }
        private void ChangeFilter(Filter f)
        {
            Bitmap objBitmap = new Bitmap(image, new Size(MainPictureBox.Width, MainPictureBox.Height));
            Bitmap newImage = new Bitmap(image, new Size(MainPictureBox.Width, MainPictureBox.Height));
            BmpPixelSnoop snoop = new BmpPixelSnoop(newImage);

            for (int i = 0; i < objBitmap.Width; i++)
            {
                for (int j = 0; j < objBitmap.Height; j++)
                {
                    snoop.SetPixel(i, j, f.calculateColor(objBitmap, i, j));
                }
            }
            snoop.Dispose();
            filteredImage = newImage;
        }
        private void Draw()
        {
            Bitmap objBitmap = new Bitmap(image, new Size(MainPictureBox.Width, MainPictureBox.Height));
            
            switch (filterType)
            {
                case FilterType.Original:
                    //MainPictureBox.Image = objBitmap;
                    break;
                case FilterType.Custom:
                    objBitmap= DrawWithFilter(customFilter);
                    break;
                case FilterType.identity:
                    objBitmap = DrawWithFilter(identityFilter);
                    break;
                case FilterType.blur:
                    objBitmap = DrawWithFilter(blurFilter);
                    break;
                case FilterType.sharpen:
                    objBitmap = DrawWithFilter(sharpenFilter);
                    break;
                case FilterType.gaussian:
                    objBitmap = DrawWithFilter(gaussianFilter);
                    break;
            }
            if (drawType == DrawType.brush)
            {
                using (Graphics grf = Graphics.FromImage(objBitmap))
                {
                    using (Brush brsh = new SolidBrush(ColorTranslator.FromHtml("#ff00ffff")))
                    {
                        grf.DrawEllipse(new Pen(Color.Black), brushPosition.X - radius, brushPosition.Y - radius, 2 * radius, 2 * radius);
                    }
                }
            }
            else if (drawType == DrawType.polygon)
            {
                using (Graphics grf = Graphics.FromImage(objBitmap))
                {
                    using (Brush brsh = new SolidBrush(ColorTranslator.FromHtml("#ff00ffff")))
                    {
                        currentPolygon.DrawShape(grf, new Pen(Color.Black));
                    }
                }
            }
            MainPictureBox.Image = objBitmap;


        }
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (((RadioButton)sender).Checked == false)
                return;
           string name = ((RadioButton)sender).Name;
           switch (name)
           {
                            case "Original":
                                filterType = FilterType.Original;
                                break;
                            case "Custom":
                                filterType = FilterType.Custom;
                                break;
                            case "Identity":
                                filterType= FilterType.identity;
                                break;
                            case "Blur":
                                filterType = FilterType.blur;
                                break;
                            case "Sharpen":
                                filterType = FilterType.sharpen;
                                break;
                            case "Gaussian":
                                filterType = FilterType.gaussian;
                                break;

           }

            switch (filterType)
            {
                case FilterType.Original:
                    filteredImage = new Bitmap(image, new Size(MainPictureBox.Width, MainPictureBox.Height));
                    break;
                case FilterType.Custom:
                    ChangeFilter(customFilter);
                    break;
                case FilterType.identity:
                    ChangeFilter(identityFilter);
                    break;
                case FilterType.blur:
                    ChangeFilter(blurFilter);
                    break;
                case FilterType.sharpen:
                    ChangeFilter(sharpenFilter);
                    break;
                case FilterType.gaussian:
                    ChangeFilter(gaussianFilter);
                    break;
            }
            Draw();
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
        private void CustomFilterInput1_ValueChanged(object sender, EventArgs e)
        {
            customFilter.changeFilter(0, 0, (int)CustomFilterInput1.Value);
            if (filterType == FilterType.Custom)
                ChangeFilter(customFilter);
            Draw();
        }
        private void CustomFilterInput2_ValueChanged(object sender, EventArgs e)
        {
            customFilter.changeFilter(0, 1, (int)CustomFilterInput2.Value);
            if (filterType == FilterType.Custom)
                ChangeFilter(customFilter);
            Draw();
        }

        private void CustomFilterInput3_ValueChanged(object sender, EventArgs e)
        {
            customFilter.changeFilter(0, 2, (int)CustomFilterInput3.Value);
            if (filterType == FilterType.Custom)
                ChangeFilter(customFilter);
            Draw();
        }

        private void CustomFilterInput4_ValueChanged(object sender, EventArgs e)
        {
            customFilter.changeFilter(1, 0, (int)CustomFilterInput4.Value);
            if (filterType == FilterType.Custom)
                ChangeFilter(customFilter);
            Draw();
        }

        private void CustomFilterInput5_ValueChanged(object sender, EventArgs e)
        {
            customFilter.changeFilter(1, 1, (int)CustomFilterInput5.Value);

            if (filterType == FilterType.Custom)
                ChangeFilter(customFilter);
            Draw();
        }

        private void CustomFilterInput6_ValueChanged(object sender, EventArgs e)
        {
            customFilter.changeFilter(1, 2, (int)CustomFilterInput6.Value);
            if(filterType==FilterType.Custom)
            ChangeFilter(customFilter);
            Draw();
        }

        private void CustomFilterInput7_ValueChanged(object sender, EventArgs e)
        {

            
            customFilter.changeFilter(2, 0, (int)CustomFilterInput7.Value);

            if (filterType == FilterType.Custom)
                ChangeFilter(customFilter);
            Draw();
        }

        private void CustomFilterInput8_ValueChanged(object sender, EventArgs e)
        {

           
            customFilter.changeFilter(2, 1, (int)CustomFilterInput8.Value);
            if (filterType == FilterType.Custom)
                ChangeFilter(customFilter);
            Draw();
        }

        private void CustomFilterInput9_ValueChanged(object sender, EventArgs e)
        {
            
            customFilter.changeFilter(2, 2, (int)CustomFilterInput9.Value);
            ChangeFilter(customFilter);
            Draw();
        }

        private void Whole_CheckedChanged(object sender, EventArgs e)
        {
            if (((RadioButton)sender).Checked == false)
                return;
          

                        string name = ((RadioButton)sender).Name;
                        switch (name)
                        {
                            case "Whole":
                                drawType = DrawType.whole;
                                break;
                            case "Polygon":
                                drawType = DrawType.polygon;
                                break;
                            case "Brush":
                                drawType= DrawType.brush;
                                break;
                        }
            Draw();
        }
        private static double GetDistance(double x1, double y1, double x2, double y2)
        {
            return Math.Sqrt(Math.Pow((x2 - x1), 2) + Math.Pow((y2 - y1), 2));
        }
        private void MainPictureBox_MouseMove(object sender, MouseEventArgs e)
        {
            if (drawType == DrawType.brush)
            {

                if (GetDistance(e.Location.X, e.Location.Y, brushPosition.X, brushPosition.Y) < 4)
                    return;

               brushPosition =  e.Location;
                Draw();
            }
            else if (drawType == DrawType.polygon&&!currentPolygon.isFinished)
            {
                
                MyPoint t = currentPolygon.GetLastVertex();
                if (t != null)
                {
                    g.DrawLine(pen, (int)t.x, (int)t.y, e.X, e.Y);
                    Draw();
                }
            }
        }

        private void BrushRadious_ValueChanged(object sender, EventArgs e)
        {
            radius = (int)BrushRadious.Value;
        }


        private void MainPictureBox_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                if (DrawType.polygon == drawType && !currentPolygon.isFinished)
                {
                    currentPolygon.AddVertex(new MyPoint(e.X, e.Y));
                }
            }
            else
            {
                if (DrawType.polygon == drawType && !currentPolygon.isFinished)
                {
                    currentPolygon.Finish();
                    Draw();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            currentPolygon = new MyPolygon();
        }

        private void load_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Image Files (*.bmp;*.jpg;*.jpeg,*.png)|*.BMP;*.JPG;*.JPEG;*.PNG";
            dialog.RestoreDirectory = false;
            dialog.AutoUpgradeEnabled = true;

            if (Directory.Exists("./Images"))
                dialog.InitialDirectory = Path.GetFullPath("./Images");

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                image = Image.FromFile(dialog.FileName);
                SetupNewImage();
            }
        }
        private void SetupNewImage()
        { 
            Bitmap objBitmap = new Bitmap(image, new Size(MainPictureBox.Width, MainPictureBox.Height));
            MainPictureBox.Image = objBitmap;
            g = Graphics.FromImage(MainPictureBox.Image);
            pen = new Pen(Color.Black, 1);
            cartesianChart1.AxisY.Clear();
            cartesianChart1.Series.Clear();
            GenerateHistogram();
            switch (filterType)
            {
                case FilterType.Original:
                    filteredImage = new Bitmap(image, new Size(MainPictureBox.Width, MainPictureBox.Height));
                    break;
                case FilterType.Custom:
                    ChangeFilter(customFilter);
                    break;
                case FilterType.identity:
                    ChangeFilter(identityFilter);
                    break;
                case FilterType.blur:
                    ChangeFilter(blurFilter);
                    break;
                case FilterType.sharpen:
                    ChangeFilter(sharpenFilter);
                    break;
                case FilterType.gaussian:
                    ChangeFilter(gaussianFilter);
                    break;
            }
            Draw();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            image = new ImageGenerator().generateBitmap(MainPictureBox.Width, MainPictureBox.Height, trackBar1.Value / 100.0);
            SetupNewImage();
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            image = new ImageGenerator().generateBitmap(MainPictureBox.Width, MainPictureBox.Height,trackBar1.Value/100.0);
            SetupNewImage();
        }
    }
}