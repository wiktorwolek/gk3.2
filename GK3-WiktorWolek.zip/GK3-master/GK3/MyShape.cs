﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace PolygonEditor
{
    public abstract class MyShape
    {
        public abstract void DrawShape(Graphics g, Pen p);
        public abstract void DrawVertexes(Graphics g, Pen p);
    }
}
