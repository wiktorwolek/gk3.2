﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GK3
{
    public class ImageGenerator
    {
        public Bitmap generateBitmap(int x,int y,double v =0.5)
        {
            Bitmap bmp = new Bitmap(x,y);
            BmpPixelSnoop bmpPixelSnoop = new BmpPixelSnoop(bmp);

           for(int i=0;i<x;i++)
                for (int j = 0; j < y; j++)
                {
                    bmpPixelSnoop.SetPixel(i, j, Color.FromArgb(255, 255, 255, 255));
                }

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < x; j++) {
                    bmpPixelSnoop.SetPixel(j, i, Color.FromArgb(255, 0, 0, 0));
                    bmpPixelSnoop.SetPixel(j, y-i-1, Color.FromArgb(255, 0, 0, 0));
                }
                for (int j = 0; j < y; j++)
                {
                    bmpPixelSnoop.SetPixel(i, j, Color.FromArgb(255,0,0,0));
                    bmpPixelSnoop.SetPixel(x-i-1, j, Color.FromArgb(255, 0, 0, 0));
                }
            }
            int k = x / 21;
            for(int i = 0; i < 10; i++)
            {
                for(int j = 0; j < k; j++)
                {
                    for (int z = y/10; z < y*9/10; z++)
                    {
                        double sat =1- ((double)z- (y / 10.0) )/ ((double)y * 8.0 / 10.0) ;
                        bmpPixelSnoop.SetPixel(k+2*i*k+j, z, ColorFromHSV(i*36,sat,v));
                    }
                }
            }
            bmpPixelSnoop.Dispose();
            return bmp;
        }
        public static void ColorToHSV(Color color, out double hue, out double saturation, out double value)
        {
            int max = Math.Max(color.R, Math.Max(color.G, color.B));
            int min = Math.Min(color.R, Math.Min(color.G, color.B));

            hue = color.GetHue();
            saturation = (max == 0) ? 0 : 1d - (1d * min / max);
            value = max / 255d;
        }

        public static Color ColorFromHSV(double hue, double saturation, double value)
        {
            int hi = Convert.ToInt32(Math.Floor(hue / 60)) % 6;
            double f = hue / 60 - Math.Floor(hue / 60);

            value = value * 255;
            int v = Convert.ToInt32(value);
            int p = Convert.ToInt32(value * (1 - saturation));
            int q = Convert.ToInt32(value * (1 - f * saturation));
            int t = Convert.ToInt32(value * (1 - (1 - f) * saturation));

            if (hi == 0)
                return Color.FromArgb(255, v, t, p);
            else if (hi == 1)
                return Color.FromArgb(255, q, v, p);
            else if (hi == 2)
                return Color.FromArgb(255, p, v, t);
            else if (hi == 3)
                return Color.FromArgb(255, p, q, v);
            else if (hi == 4)
                return Color.FromArgb(255, t, p, v);
            else
                return Color.FromArgb(255, v, p, q);
        }

    }
}
