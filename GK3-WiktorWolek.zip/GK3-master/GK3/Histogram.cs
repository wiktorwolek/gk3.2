﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GK3
{
    public class Histogram
    {
        public int pixel { get; set; }
        public int colorPixel { get; set; }
    }
}
